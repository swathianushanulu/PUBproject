package com.sat.StepDefinitions;

import java.util.List;

public class BaseStepDefs {
	


	


}
