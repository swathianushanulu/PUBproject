package com.sat.testUtil;

import com.sat.testbase.TestBase;

public class Testutil extends TestBase {
	
	public static long PAGE_LOAD_TIMEOUT = 50;
	public static long IMPLICIT_WAIT = 40;
	public static long EXPLICIT_WAIT = 5000;

}
