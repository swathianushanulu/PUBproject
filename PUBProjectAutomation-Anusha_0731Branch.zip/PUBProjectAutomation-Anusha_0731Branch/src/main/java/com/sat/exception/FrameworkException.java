package com.sat.exception;

public class FrameworkException extends RuntimeException {
	public FrameworkException(String mesg) {
		super(mesg);
	}
}
